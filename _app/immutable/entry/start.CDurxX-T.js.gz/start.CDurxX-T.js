import{a as t}from"../chunks/entry.B-GZb9Nj.js";export{t as start};
